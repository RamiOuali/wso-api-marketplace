"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Trash2, MoveUp, MoveDown, Upload, X } from "lucide-react"
import { toast } from "sonner"

interface ImageCard {
  id: string
  imageUrl: string
  alt: string
}

interface ImageCardsSectionConfig {
  title: string
  subtitle: string
  cards: ImageCard[]
  columns: 2 | 3 | 4
  gap: "small" | "medium" | "large"
  rounded: "none" | "small" | "medium" | "large"
  shadow: "none" | "small" | "medium" | "large"
  aspectRatio: "square" | "landscape" | "portrait" | "auto"
  hoverEffect: "none" | "zoom" | "lift" | "glow"
}

const defaultConfig: ImageCardsSectionConfig = {
  title: "Image Gallery",
  subtitle: "A collection of images",
  cards: [],
  columns: 3,
  gap: "medium",
  rounded: "medium",
  shadow: "medium",
  aspectRatio: "landscape",
  hoverEffect: "zoom",
}

export function ImageCardsEditor() {
  const [config, setConfig] = useState<ImageCardsSectionConfig>(defaultConfig)
  const [activeTab, setActiveTab] = useState("content")

  const handleConfigChange = (field: keyof ImageCardsSectionConfig, value: any) => {
    setConfig((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const addCard = () => {
    const newCard: ImageCard = {
      id: `card-${Date.now()}`,
      imageUrl: "/placeholder.svg?height=400&width=600",
      alt: "Image description",
    }

    setConfig((prev) => ({
      ...prev,
      cards: [...prev.cards, newCard],
    }))
  }

  const updateCard = (id: string, field: keyof ImageCard, value: string) => {
    setConfig((prev) => ({
      ...prev,
      cards: prev.cards.map((card) => (card.id === id ? { ...card, [field]: value } : card)),
    }))
  }

  const removeCard = (id: string) => {
    setConfig((prev) => ({
      ...prev,
      cards: prev.cards.filter((card) => card.id !== id),
    }))
  }

  const moveCard = (id: string, direction: "up" | "down") => {
    const cardIndex = config.cards.findIndex((card) => card.id === id)
    if ((direction === "up" && cardIndex === 0) || (direction === "down" && cardIndex === config.cards.length - 1)) {
      return
    }

    const newCards = [...config.cards]
    const newIndex = direction === "up" ? cardIndex - 1 : cardIndex + 1
    const card = newCards[cardIndex]
    newCards.splice(cardIndex, 1)
    newCards.splice(newIndex, 0, card)

    setConfig((prev) => ({
      ...prev,
      cards: newCards,
    }))
  }

  const handleSave = () => {
    // In a real app, you would save the config to your backend
    toast.success("Section saved", {
      description: "Your image cards section has been saved successfully.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Image Cards Section</h2>
          <p className="text-muted-foreground">Configure the image cards section for your landing page</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleSave}>Save Section</Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="content">Content</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="content" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Section Header</CardTitle>
              <CardDescription>Configure the title and subtitle for this section</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Section Title</Label>
                <Input
                  id="title"
                  value={config.title}
                  onChange={(e) => handleConfigChange("title", e.target.value)}
                  placeholder="Enter section title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subtitle">Section Subtitle</Label>
                <Textarea
                  id="subtitle"
                  value={config.subtitle}
                  onChange={(e) => handleConfigChange("subtitle", e.target.value)}
                  placeholder="Enter section subtitle"
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Image Cards</CardTitle>
                <CardDescription>Add and manage image cards</CardDescription>
              </div>
              <Button onClick={addCard} size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Add Card
              </Button>
            </CardHeader>
            <CardContent>
              {config.cards.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <div className="rounded-full bg-slate-100 p-3 mb-4">
                    <Upload className="h-6 w-6 text-slate-400" />
                  </div>
                  <h3 className="text-lg font-medium mb-1">No images added</h3>
                  <p className="text-sm text-muted-foreground mb-4">Add images to display in this section</p>
                  <Button onClick={addCard}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Image Card
                  </Button>
                </div>
              ) : (
                <div className="space-y-6">
                  {config.cards.map((card, index) => (
                    <Card key={card.id} className="overflow-hidden">
                      <div className="relative aspect-video bg-slate-100">
                        <Image
                          src={card.imageUrl || "/placeholder.svg"}
                          alt={card.alt}
                          fill
                          className="object-cover"
                          sizes="(max-width: 768px) 100vw, 500px"
                        />
                        <div className="absolute top-2 right-2 flex gap-1">
                          <Button
                            variant="destructive"
                            size="icon"
                            className="h-8 w-8 bg-red-500/80 hover:bg-red-500"
                            onClick={() => removeCard(card.id)}
                          >
                            <X className="h-4 w-4" />
                            <span className="sr-only">Remove</span>
                          </Button>
                        </div>
                      </div>
                      <CardContent className="pt-4 space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor={`image-url-${card.id}`}>Image URL</Label>
                          <Input
                            id={`image-url-${card.id}`}
                            value={card.imageUrl}
                            onChange={(e) => updateCard(card.id, "imageUrl", e.target.value)}
                            placeholder="Enter image URL"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor={`alt-${card.id}`}>Alt Text</Label>
                          <Input
                            id={`alt-${card.id}`}
                            value={card.alt}
                            onChange={(e) => updateCard(card.id, "alt", e.target.value)}
                            placeholder="Enter alt text for accessibility"
                          />
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between border-t pt-4">
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => moveCard(card.id, "up")}
                            disabled={index === 0}
                          >
                            <MoveUp className="h-4 w-4" />
                            <span className="sr-only">Move up</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => moveCard(card.id, "down")}
                            disabled={index === config.cards.length - 1}
                          >
                            <MoveDown className="h-4 w-4" />
                            <span className="sr-only">Move down</span>
                          </Button>
                        </div>
                        <Button variant="destructive" size="sm" onClick={() => removeCard(card.id)} className="h-8">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Remove
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Layout Settings</CardTitle>
              <CardDescription>Configure the layout and appearance of the image cards</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="columns">Columns</Label>
                  <Select
                    value={config.columns.toString()}
                    onValueChange={(value) => handleConfigChange("columns", Number(value) as 2 | 3 | 4)}
                  >
                    <SelectTrigger id="columns">
                      <SelectValue placeholder="Select columns" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2">2 Columns</SelectItem>
                      <SelectItem value="3">3 Columns</SelectItem>
                      <SelectItem value="4">4 Columns</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="gap">Gap Size</Label>
                  <Select
                    value={config.gap}
                    onValueChange={(value) => handleConfigChange("gap", value as "small" | "medium" | "large")}
                  >
                    <SelectTrigger id="gap">
                      <SelectValue placeholder="Select gap size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="large">Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="rounded">Corner Radius</Label>
                  <Select
                    value={config.rounded}
                    onValueChange={(value) =>
                      handleConfigChange("rounded", value as "none" | "small" | "medium" | "large")
                    }
                  >
                    <SelectTrigger id="rounded">
                      <SelectValue placeholder="Select corner radius" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="small">Small</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="large">Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="shadow">Shadow</Label>
                  <Select
                    value={config.shadow}
                    onValueChange={(value) =>
                      handleConfigChange("shadow", value as "none" | "small" | "medium" | "large")
                    }
                  >
                    <SelectTrigger id="shadow">
                      <SelectValue placeholder="Select shadow" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="small">Small</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="large">Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="aspectRatio">Aspect Ratio</Label>
                  <Select
                    value={config.aspectRatio}
                    onValueChange={(value) =>
                      handleConfigChange("aspectRatio", value as "square" | "landscape" | "portrait" | "auto")
                    }
                  >
                    <SelectTrigger id="aspectRatio">
                      <SelectValue placeholder="Select aspect ratio" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="square">Square (1:1)</SelectItem>
                      <SelectItem value="landscape">Landscape (16:9)</SelectItem>
                      <SelectItem value="portrait">Portrait (3:4)</SelectItem>
                      <SelectItem value="auto">Auto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="hoverEffect">Hover Effect</Label>
                  <Select
                    value={config.hoverEffect}
                    onValueChange={(value) =>
                      handleConfigChange("hoverEffect", value as "none" | "zoom" | "lift" | "glow")
                    }
                  >
                    <SelectTrigger id="hoverEffect">
                      <SelectValue placeholder="Select hover effect" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="zoom">Zoom</SelectItem>
                      <SelectItem value="lift">Lift</SelectItem>
                      <SelectItem value="glow">Glow</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Preview</CardTitle>
          <CardDescription>Preview how your image cards section will look</CardDescription>
        </CardHeader>
        <CardContent className="border-t pt-6">
          <div className="bg-white rounded-lg overflow-hidden">
            <div className="py-8">
              {config.title && <h2 className="text-2xl font-bold text-center mb-2">{config.title}</h2>}
              {config.subtitle && <p className="text-center text-gray-500 mb-6">{config.subtitle}</p>}

              <div
                className={`grid gap-${config.gap === "small" ? "2" : config.gap === "medium" ? "4" : "8"} grid-cols-1 sm:grid-cols-${
                  config.columns >= 2 ? "2" : "1"
                } lg:grid-cols-${config.columns} px-4`}
              >
                {config.cards.map((card) => (
                  <div
                    key={card.id}
                    className={`overflow-hidden rounded-${
                      config.rounded === "none"
                        ? "none"
                        : config.rounded === "small"
                          ? "sm"
                          : config.rounded === "medium"
                            ? "md"
                            : "lg"
                    } shadow-${
                      config.shadow === "none"
                        ? "none"
                        : config.shadow === "small"
                          ? "sm"
                          : config.shadow === "medium"
                            ? ""
                            : "lg"
                    }`}
                  >
                    <div
                      className={`relative ${
                        config.aspectRatio === "square"
                          ? "aspect-square"
                          : config.aspectRatio === "landscape"
                            ? "aspect-video"
                            : config.aspectRatio === "portrait"
                              ? "aspect-[3/4]"
                              : ""
                      }`}
                    >
                      <Image
                        src={card.imageUrl || "/placeholder.svg"}
                        alt={card.alt}
                        fill
                        className="object-cover"
                        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                      />
                    </div>
                  </div>
                ))}

                {config.cards.length === 0 &&
                  Array.from({ length: config.columns }).map((_, index) => (
                    <div
                      key={index}
                      className={`bg-slate-100 rounded-${
                        config.rounded === "none"
                          ? "none"
                          : config.rounded === "small"
                            ? "sm"
                            : config.rounded === "medium"
                              ? "md"
                              : "lg"
                      }`}
                    >
                      <div
                        className={`flex items-center justify-center ${
                          config.aspectRatio === "square"
                            ? "aspect-square"
                            : config.aspectRatio === "landscape"
                              ? "aspect-video"
                              : config.aspectRatio === "portrait"
                                ? "aspect-[3/4]"
                                : "h-40"
                        }`}
                      >
                        <p className="text-sm text-slate-400">Add image</p>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
