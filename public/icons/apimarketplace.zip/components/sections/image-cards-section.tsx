"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { useThemeContext } from "@/providers/ThemeProvider"
import { cn } from "@/lib/utils"

interface ImageCard {
  id: string
  imageUrl: string
  alt: string
}

interface ImageCardsSectionProps {
  title?: string
  subtitle?: string
  cards: ImageCard[]
  columns?: 2 | 3 | 4
  gap?: "small" | "medium" | "large"
  rounded?: "none" | "small" | "medium" | "large"
  shadow?: "none" | "small" | "medium" | "large"
  aspectRatio?: "square" | "landscape" | "portrait" | "auto"
  hoverEffect?: "none" | "zoom" | "lift" | "glow"
  className?: string
}

export function ImageCardsSection({
  title,
  subtitle,
  cards = [],
  columns = 3,
  gap = "medium",
  rounded = "medium",
  shadow = "medium",
  aspectRatio = "landscape",
  hoverEffect = "zoom",
  className,
}: ImageCardsSectionProps) {
  const { theme } = useThemeContext()
  const [isLoading, setIsLoading] = useState(true)

  // Return early if no theme is available
  if (!theme) {
    return <div className="py-12">Loading...</div>
  }

  // Map gap size to Tailwind classes
  const gapClasses = {
    small: "gap-2",
    medium: "gap-4",
    large: "gap-8",
  }

  // Map rounded size to Tailwind classes
  const roundedClasses = {
    none: "rounded-none",
    small: "rounded-sm",
    medium: "rounded-md",
    large: "rounded-lg",
  }

  // Map shadow size to Tailwind classes
  const shadowClasses = {
    none: "shadow-none",
    small: "shadow-sm",
    medium: "shadow",
    large: "shadow-lg",
  }

  // Map aspect ratio to Tailwind classes
  const aspectRatioClasses = {
    square: "aspect-square",
    landscape: "aspect-video",
    portrait: "aspect-[3/4]",
    auto: "aspect-auto",
  }

  // Map hover effect to Tailwind classes
  const hoverEffectClasses = {
    none: "",
    zoom: "group-hover:scale-105",
    lift: "group-hover:-translate-y-2",
    glow: "",
  }

  // Map columns to Tailwind grid classes
  const columnClasses = {
    2: "grid-cols-1 sm:grid-cols-2",
    3: "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
    4: "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4",
  }

  return (
    <section
      className={cn("py-12", className)}
      style={{
        backgroundColor: theme.backgroundColor,
        color: theme.textColor,
      }}
    >
      <div className="container mx-auto px-4">
        {/* Section header */}
        {(title || subtitle) && (
          <div className="text-center mb-10">
            {title && (
              <h2
                className="text-3xl font-bold mb-4"
                style={{
                  fontFamily: theme.headingFont,
                  color: theme.textColor,
                }}
              >
                {title}
              </h2>
            )}
            {subtitle && (
              <p
                className="text-lg max-w-3xl mx-auto"
                style={{
                  color: theme.textColor,
                  opacity: 0.8,
                }}
              >
                {subtitle}
              </p>
            )}
          </div>
        )}

        {/* Image cards grid */}
        <div className={cn("grid", columnClasses[columns], gapClasses[gap])}>
          {cards.map((card) => (
            <div
              key={card.id}
              className={cn(
                "group overflow-hidden transition-all duration-300",
                roundedClasses[rounded],
                shadowClasses[shadow],
                hoverEffect === "glow" && "hover:shadow-glow",
                hoverEffect === "lift" && "hover:shadow-lg",
              )}
              style={
                {
                  backgroundColor: theme.cardBackground,
                  borderColor: theme.cardBorderColor,
                  boxShadow: shadow !== "none" ? theme.cardShadow : "none",
                  "--glow-color": `${theme.primaryColor}33`,
                } as React.CSSProperties
              }
            >
              <div className={cn("overflow-hidden", aspectRatioClasses[aspectRatio])}>
                <div className="relative w-full h-full">
                  <Image
                    src={card.imageUrl || "/placeholder.svg"}
                    alt={card.alt}
                    fill
                    className={cn(
                      "object-cover transition-transform duration-500",
                      isLoading ? "blur-sm" : "blur-0",
                      hoverEffectClasses[hoverEffect],
                    )}
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    onLoad={() => setIsLoading(false)}
                  />
                </div>
              </div>
            </div>
          ))}

          {/* Show placeholder cards if no cards are provided */}
          {cards.length === 0 &&
            Array.from({ length: columns }).map((_, index) => (
              <div
                key={index}
                className={cn("overflow-hidden", roundedClasses[rounded], shadowClasses[shadow])}
                style={{
                  backgroundColor: theme.cardBackground,
                  borderColor: theme.cardBorderColor,
                  boxShadow: shadow !== "none" ? theme.cardShadow : "none",
                }}
              >
                <div className={cn("bg-slate-100", aspectRatioClasses[aspectRatio])}>
                  <div className="flex items-center justify-center w-full h-full">
                    <p className="text-sm text-slate-400">Add image</p>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
    </section>
  )
}
