"use client"

import { buttonVariants } from "@/components/ui/button"

import type { ButtonProps } from "@/components/ui/button"

import { cn } from "@/lib/utils"

import React from "react"

import { ChevronLeft, ChevronRight, MoreHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useThemeContext } from "@/providers/ThemeProvider"

interface PaginationProps {
  currentPage: number
  totalPages: number
  onPageChange: (page: number) => void
  maxDisplayedPages?: number
}

export function Pagination({ currentPage, totalPages, onPageChange, maxDisplayedPages = 5 }: PaginationProps) {
  const { theme } = useThemeContext()

  // Don't render pagination if there's only one page
  if (totalPages <= 1) return null

  // Calculate the range of pages to display
  const getPageRange = () => {
    if (totalPages <= maxDisplayedPages) {
      // If total pages is less than or equal to max displayed, show all pages
      return Array.from({ length: totalPages }, (_, i) => i + 1)
    }

    // Always include first and last page
    const range: (number | string)[] = []

    // Calculate the middle range
    const sidePages = Math.floor((maxDisplayedPages - 2) / 2)
    let startPage = Math.max(2, currentPage - sidePages)
    let endPage = Math.min(totalPages - 1, currentPage + sidePages)

    // Adjust if we're near the beginning or end
    if (currentPage - sidePages < 2) {
      endPage = Math.min(totalPages - 1, maxDisplayedPages - 1)
    }
    if (currentPage + sidePages > totalPages - 1) {
      startPage = Math.max(2, totalPages - maxDisplayedPages + 2)
    }

    // Add first page
    range.push(1)

    // Add ellipsis if needed
    if (startPage > 2) {
      range.push("ellipsis-start")
    }

    // Add middle pages
    for (let i = startPage; i <= endPage; i++) {
      range.push(i)
    }

    // Add ellipsis if needed
    if (endPage < totalPages - 1) {
      range.push("ellipsis-end")
    }

    // Add last page if not already included
    if (totalPages > 1) {
      range.push(totalPages)
    }

    return range
  }

  const pageRange = getPageRange()

  return (
    <div className="flex items-center justify-center space-x-2">
      <Button
        variant="outline"
        size="icon"
        onClick={() => onPageChange(Math.max(1, currentPage - 1))}
        disabled={currentPage === 1}
        style={{
          borderColor: theme?.buttonSecondaryColor || "#6c757d",
          color: theme?.buttonSecondaryColor || "#6c757d",
        }}
      >
        <ChevronLeft className="h-4 w-4" />
        <span className="sr-only">Previous page</span>
      </Button>

      {pageRange.map((page, index) => {
        if (page === "ellipsis-start" || page === "ellipsis-end") {
          return (
            <Button
              key={`ellipsis-${index}`}
              variant="outline"
              size="icon"
              disabled
              style={{
                borderColor: "transparent",
              }}
            >
              <MoreHorizontal className="h-4 w-4" />
              <span className="sr-only">More pages</span>
            </Button>
          )
        }

        return (
          <Button
            key={page}
            variant={currentPage === page ? "default" : "outline"}
            size="icon"
            onClick={() => onPageChange(page as number)}
            style={
              currentPage === page
                ? {
                    backgroundColor: theme?.buttonPrimaryColor || "#0070f3",
                    color: theme?.buttonTextColor || "#ffffff",
                  }
                : {
                    borderColor: theme?.buttonSecondaryColor || "#6c757d",
                    color: theme?.buttonSecondaryColor || "#6c757d",
                  }
            }
          >
            {page}
            <span className="sr-only">Page {page}</span>
          </Button>
        )
      })}

      <Button
        variant="outline"
        size="icon"
        onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
        disabled={currentPage === totalPages}
        style={{
          borderColor: theme?.buttonSecondaryColor || "#6c757d",
          color: theme?.buttonSecondaryColor || "#6c757d",
        }}
      >
        <ChevronRight className="h-4 w-4" />
        <span className="sr-only">Next page</span>
      </Button>
    </div>
  )
}

const PaginationContent = React.forwardRef<HTMLUListElement, React.ComponentProps<"ul">>(
  ({ className, ...props }, ref) => (
    <ul ref={ref} className={cn("flex flex-row items-center gap-1", className)} {...props} />
  ),
)
PaginationContent.displayName = "PaginationContent"

const PaginationItem = React.forwardRef<HTMLLIElement, React.ComponentProps<"li">>(({ className, ...props }, ref) => (
  <li ref={ref} className={cn("", className)} {...props} />
))
PaginationItem.displayName = "PaginationItem"

type PaginationLinkProps = {
  isActive?: boolean
} & Pick<ButtonProps, "size"> &
  React.ComponentProps<"a">

const PaginationLink = ({ className, isActive, size = "icon", ...props }: PaginationLinkProps) => (
  <a
    aria-current={isActive ? "page" : undefined}
    className={cn(
      buttonVariants({
        variant: isActive ? "outline" : "ghost",
        size,
      }),
      className,
    )}
    {...props}
  />
)
PaginationLink.displayName = "PaginationLink"

const PaginationPrevious = ({ className, ...props }: React.ComponentProps<typeof PaginationLink>) => (
  <PaginationLink aria-label="Go to previous page" size="default" className={cn("gap-1 pl-2.5", className)} {...props}>
    <ChevronLeft className="h-4 w-4" />
    <span>Previous</span>
  </PaginationLink>
)
PaginationPrevious.displayName = "PaginationPrevious"

const PaginationNext = ({ className, ...props }: React.ComponentProps<typeof PaginationLink>) => (
  <PaginationLink aria-label="Go to next page" size="default" className={cn("gap-1 pr-2.5", className)} {...props}>
    <span>Next</span>
    <ChevronRight className="h-4 w-4" />
  </PaginationLink>
)
PaginationNext.displayName = "PaginationNext"

const PaginationEllipsis = ({ className, ...props }: React.ComponentProps<"span">) => (
  <span aria-hidden className={cn("flex h-9 w-9 items-center justify-center", className)} {...props}>
    <MoreHorizontal className="h-4 w-4" />
    <span className="sr-only">More pages</span>
  </span>
)
PaginationEllipsis.displayName = "PaginationEllipsis"

export { PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious }
