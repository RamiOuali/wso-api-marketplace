"use client"
import Link from "next/link"
import Image from "next/image"
import { Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useThemeContext } from "@/providers/ThemeProvider"

export function Footer() {
  const { theme } = useThemeContext()

  // Add early return with loading indicator
  if (!theme) {
    return (
      <footer className="border-t bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center">
            <div>Loading...</div>
          </div>
        </div>
      </footer>
    )
  }

  // Default social links as fallback
  const defaultSocialLinks = [
    { name: "Twitter", url: "https://twitter.com", icon: "/icons/twitter.svg" },
    { name: "LinkedIn", url: "https://linkedin.com", icon: "/icons/linkedin.svg" },
    { name: "GitHub", url: "https://github.com", icon: "/icons/github.svg" },
  ]

  // Safely access social links with fallback
  const socialLinks = theme.socialLinks || defaultSocialLinks

  // Default footer columns as fallback
  const defaultFooterColumns = {
    products: {
      title: "Products",
      links: [
        { title: "APIs", href: "/apis" },
        { title: "Documentation", href: "/docs" },
        { title: "Pricing", href: "/pricing" },
      ],
    },
    resources: {
      title: "Resources",
      links: [
        { title: "Blog", href: "/blog" },
        { title: "Support", href: "/support" },
        { title: "FAQ", href: "/faq" },
      ],
    },
    company: {
      title: "Company",
      links: [
        { title: "About", href: "/about" },
        { title: "Careers", href: "/careers" },
        { title: "Contact", href: "/contact" },
      ],
    },
    legal: {
      title: "Legal",
      links: [
        { title: "Privacy Policy", href: "/privacy" },
        { title: "Terms of Service", href: "/terms" },
        { title: "Cookie Policy", href: "/cookies" },
      ],
    },
  }

  // Safely access footer columns with fallback
  const footerColumns = theme.footerColumns || defaultFooterColumns

  // Default logo path
  const logoPath = theme.footerLogo || "/images/logo-white.png"

  return (
    <footer
      className="border-t"
      style={{
        fontFamily: theme.bodyFont,
        backgroundColor: theme.footerBackground,
        color: theme.footerTextColor,
      }}
    >
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-5">
          {/* Logo and description */}
          <div className="lg:col-span-2">
            <Link href="/" className="inline-block">
              <div className="relative h-8 w-auto mb-4">
                <Image
                  src={logoPath || "/placeholder.svg"}
                  alt="Logo"
                  width={107}
                  height={24}
                  className="object-contain"
                  style={{ maxHeight: "24px" }}
                />
              </div>
            </Link>
            <p className="mt-4 max-w-xs text-sm opacity-80">
              {theme.siteDescription ||
                "Discover and connect with our APIs. Build powerful integrations with our marketplace."}
            </p>

            {/* Social links */}
            {theme.footerShowSocial && (
              <div className="mt-6 flex space-x-4">
                {socialLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-full p-2 transition-colors hover:bg-white/10"
                    aria-label={link.name}
                  >
                    <div className="relative h-5 w-5">
                      <Image
                        src={link.icon || "/placeholder.svg"}
                        alt={link.name}
                        width={20}
                        height={20}
                        className="object-contain"
                      />
                    </div>
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* Footer columns */}
          {Object.keys(footerColumns).map((key) => {
            const column = footerColumns[key]
            return (
              <div key={key} className="space-y-4">
                <h4 className="text-sm font-semibold uppercase tracking-wider">{column.title}</h4>
                <ul className="space-y-2">
                  {column.links.map((link) => (
                    <li key={link.title}>
                      <Link href={link.href} className="text-sm opacity-80 transition-opacity hover:opacity-100">
                        {link.title}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            )
          })}

          {/* Newsletter */}
          {theme.footerShowNewsletter && (
            <div className="lg:col-span-2 space-y-4">
              <h4 className="text-sm font-semibold uppercase tracking-wider">Subscribe to our newsletter</h4>
              <p className="text-sm opacity-80">Stay updated with the latest APIs and features</p>
              <div className="flex max-w-sm space-x-2">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="bg-white/10 border-white/20"
                  style={{
                    backgroundColor: `${theme.inputBackground}20`,
                    borderColor: `${theme.inputBorderColor}40`,
                    color: theme.footerTextColor,
                  }}
                />
                <Button
                  type="submit"
                  style={{
                    backgroundColor: theme.buttonPrimaryColor,
                    color: theme.buttonTextColor,
                  }}
                >
                  <Mail className="mr-2 h-4 w-4" />
                  Subscribe
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Copyright */}
        <div className="mt-12 border-t border-white/10 pt-8">
          <div className="flex flex-col items-center justify-between space-y-4 md:flex-row md:space-y-0">
            <p className="text-sm opacity-80">
              {theme.footerCopyright || `© ${new Date().getFullYear()} API Marketplace. All rights reserved.`}
            </p>
            <div className="flex space-x-6">
              <Link href="/privacy" className="text-sm opacity-80 transition-opacity hover:opacity-100">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-sm opacity-80 transition-opacity hover:opacity-100">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
