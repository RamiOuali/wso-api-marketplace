"use client"

import * as React from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname, useRouter } from "next/navigation"
import { Menu, Search, Globe, ChevronDown, Bell, User, LogOut, Settings, HelpCircle, X, Code } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuGroup,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetClose, SheetTrigger } from "@/components/ui/sheet"
import { useThemeContext } from "@/providers/ThemeProvider"
import { Badge } from "@/components/ui/badge"
import { WSO2AuthModal } from "@/components/wso2/auth-modal"
import { WSO2AuthService } from "@/lib/wso2/auth-service"

export function Navbar() {
  const { theme } = useThemeContext()
  const pathname = usePathname()
  const router = useRouter()
  const [showMobileSearch, setShowMobileSearch] = React.useState(false)
  const [authModalOpen, setAuthModalOpen] = React.useState(false)
  const [isAuthenticated, setIsAuthenticated] = React.useState(false)
  const [isPublicMode, setIsPublicMode] = React.useState(false)
  const [username, setUsername] = React.useState<string>("")
  const [authService, setAuthService] = React.useState<WSO2AuthService | null>(null)

  React.useEffect(() => {
    // Listen for custom event to open auth modal from other components
    const handleOpenAuthModal = () => {
      setAuthModalOpen(true)
    }

    document.addEventListener("openWso2AuthModal", handleOpenAuthModal)

    // Clean up event listener
    return () => {
      document.removeEventListener("openWso2AuthModal", handleOpenAuthModal)
    }
  }, [])

  // Check for existing authentication on component mount
  React.useEffect(() => {
    try {
      const storedBaseUrl = localStorage.getItem("wso2_baseUrl")
      const storedUsername = localStorage.getItem("wso2_username")
      const accessToken = localStorage.getItem("wso2_accessToken")
      const publicMode = localStorage.getItem("wso2_publicMode") === "true"

      if (storedBaseUrl) {
        if (storedUsername && accessToken) {
          setUsername(storedUsername)
          setIsAuthenticated(true)

          // Create auth service with stored credentials
          const auth = new WSO2AuthService(storedBaseUrl)

          // Set auth service properties
          const clientId = localStorage.getItem("wso2_clientId")
          const clientSecret = localStorage.getItem("wso2_clientSecret")
          const refreshToken = localStorage.getItem("wso2_refreshToken")
          const tokenExpiry = localStorage.getItem("wso2_tokenExpiry")

          if (clientId && clientSecret && accessToken && refreshToken && tokenExpiry) {
            Object.assign(auth, {
              clientId,
              clientSecret,
              accessToken,
              refreshToken,
              tokenExpiry: Number.parseInt(tokenExpiry, 10),
            })

            setAuthService(auth)
          }
        } else if (publicMode) {
          setIsPublicMode(true)
          const auth = new WSO2AuthService(storedBaseUrl)
          setAuthService(auth)
        }
      }
    } catch (err) {
      console.error("Error accessing localStorage:", err)
    }
  }, [])

  const handleAuthSuccess = (auth: WSO2AuthService, publicMode: boolean, user?: string) => {
    setAuthService(auth)

    if (publicMode) {
      setIsPublicMode(true)
      setIsAuthenticated(false)
    } else {
      setIsAuthenticated(true)
      setIsPublicMode(false)
      if (user) {
        setUsername(user)
      }
    }
  }

  const handleLogout = () => {
    // Clear auth-related localStorage items
    localStorage.removeItem("wso2_username")
    localStorage.removeItem("wso2_clientId")
    localStorage.removeItem("wso2_clientSecret")
    localStorage.removeItem("wso2_accessToken")
    localStorage.removeItem("wso2_refreshToken")
    localStorage.removeItem("wso2_tokenExpiry")
    localStorage.removeItem("wso2_publicMode")

    // Reset state
    setIsAuthenticated(false)
    setIsPublicMode(false)
    setAuthService(null)
    setUsername("")
  }

  const navigateToApiConsole = () => {
    router.push("/wso2")
  }

  // Add early return with loading indicator
  if (!theme) {
    return (
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            <div>Loading...</div>
          </div>
        </div>
      </header>
    )
  }

  // Create default nav items as a fallback
  const defaultNavItems = [
    { title: "Home", href: "/", isExternal: false },
    { title: "APIs", href: "/apis", isExternal: false },
    { title: "Documentation", href: "/docs", isExternal: false },
    { title: "Pricing", href: "/pricing", isExternal: false },
  ]

  // Create default user menu items
  const defaultUserMenuItems = [
    { title: "Profile", href: "/profile", icon: User },
    { title: "API Console", href: "/wso2", icon: Code },
    { title: "Settings", href: "/settings", icon: Settings },
    { title: "Help", href: "/help", icon: HelpCircle },
    { title: "Sign out", href: "#", icon: LogOut, action: handleLogout },
  ]

  // Safely access navItems with fallback
  const navItems = theme.navItems || defaultNavItems

  // Filter nav items based on settings
  const filteredNavItems = theme.navbarShowUserMenu ? navItems : navItems.filter((item) => item.title !== "About Us")

  // Get languages with fallback
  const languages = theme.languages || []

  // Default logo path
  const logoPath = theme.navbarLogo || "/images/logo.png"

  // Parse navbar height with fallback
  const navbarHeight = theme.navbarHeight || "64px"
  const navbarHeightPx = Number.parseInt(navbarHeight.replace("px", ""), 10) || 64

  return (
    <>
      <header
        className={cn(
          "top-0 z-50 w-full backdrop-blur supports-[backdrop-filter]:bg-background/60",
          theme.navbarPosition === "sticky" ? "sticky" : "",
          theme.navbarPosition === "fixed" ? "fixed" : "",
        )}
        style={{
          position: theme.navbarPosition || "sticky",
          fontFamily: theme.bodyFont,
          backgroundColor: theme.navbarBackground,
          color: theme.navbarTextColor,
          height: navbarHeight,
          borderBottom: `1px solid ${theme.navbarBorderColor || theme.borderColor || "#e5e7eb"}`,
        }}
      >
        <div className="container mx-auto px-4">
          <div className="flex h-full items-center justify-between">
            {/* Logo */}
            <div className="flex shrink-0 items-center">
              <Link href="/" className="flex items-center space-x-2">
                <div className="relative h-8 w-auto">
                  <Image
                    src={logoPath || "/placeholder.svg"}
                    alt="Logo"
                    width={107}
                    height={24}
                    className="object-contain"
                    style={{ maxHeight: "24px" }}
                    priority
                  />
                </div>
                {theme.siteTitle && (
                  <span
                    className="hidden lg:inline-block font-semibold text-lg"
                    style={{ color: theme.navbarTextColor }}
                  >
                    {theme.siteTitle}
                  </span>
                )}
              </Link>
            </div>

            {/* Desktop navigation */}
            <nav className="hidden md:flex flex-1 h-full items-center justify-center">
              <ul className="flex space-x-8 h-full">
                {filteredNavItems.map((item) => (
                  <li key={item.href} className="flex h-full">
                    {item.isExternal ? (
                      <a
                        href={item.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={cn(
                          "flex items-center text-sm font-medium transition-colors hover:opacity-80 h-full",
                        )}
                        style={{ color: theme.navbarTextColor }}
                      >
                        {item.icon && <span className="mr-1">{item.icon}</span>}
                        {item.title}
                      </a>
                    ) : (
                      <Link
                        href={item.href}
                        className={cn(
                          "flex items-center justify-center text-sm font-medium transition-colors hover:opacity-80 relative h-full",
                        )}
                        style={{
                          color:
                            pathname === item.href
                              ? theme.primaryColor || theme.navbarActiveColor || theme.navbarTextColor
                              : theme.navbarTextColor,
                        }}
                      >
                        <div className="flex items-center">
                          {item.icon && <span className="mr-1">{item.icon}</span>}
                          {item.title}
                        </div>
                        {pathname === item.href && (
                          <span
                            className="absolute bottom-0 left-0 w-full h-[2px]"
                            style={{ backgroundColor: theme.primaryColor || theme.accentColor || "#0070f3" }}
                          />
                        )}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </nav>

            {/* Desktop action buttons */}
            <div className="hidden md:flex items-center space-x-3">
              {/* Search */}
              {theme.navbarShowSearch && (
                <div className="relative w-60">
                  <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Search APIs..."
                    className="pl-8 h-9"
                    style={{
                      backgroundColor: `${theme.inputBackground}`,
                      borderColor: `${theme.inputBorderColor || "#d1d5db"}`,
                      color: theme.inputTextColor,
                      borderRadius: theme.inputBorderRadius || "0.375rem",
                    }}
                  />
                </div>
              )}

              {/* Language selector */}
              {theme.navbarShowLanguage && languages.length > 0 && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-8 px-2" style={{ color: theme.navbarTextColor }}>
                      <Globe className="h-4 w-4 mr-1" />
                      <span>{languages[0].code?.toUpperCase() || "EN"}</span>
                      <ChevronDown className="h-4 w-4 ml-1 opacity-50" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-40">
                    {languages.map((lang) => (
                      <DropdownMenuItem key={lang.code}>{lang.name || lang.code}</DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}

              {/* Notifications */}
              {theme.navbarShowNotifications && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="relative h-8 w-8"
                      style={{ color: theme.navbarTextColor }}
                    >
                      <Bell className="h-4 w-4" />
                      <Badge
                        className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center text-[10px]"
                        style={{ backgroundColor: theme.accentColor }}
                      >
                        3
                      </Badge>
                      <span className="sr-only">Notifications</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-80">
                    <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <div className="max-h-80 overflow-auto">
                      {[1, 2, 3].map((i) => (
                        <DropdownMenuItem key={i} className="flex items-start py-2 px-4 cursor-pointer">
                          <div className="flex-shrink-0 mr-3 mt-0.5">
                            <div className="h-8 w-8 rounded-full bg-slate-100 flex items-center justify-center">
                              <Bell className="h-4 w-4" />
                            </div>
                          </div>
                          <div className="flex-1 space-y-1">
                            <p className="text-sm font-medium">New API Available</p>
                            <p className="text-xs text-muted-foreground">The Weather API v2 is now available</p>
                            <p className="text-xs text-muted-foreground">2 hours ago</p>
                          </div>
                        </DropdownMenuItem>
                      ))}
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="justify-center text-sm font-medium text-center">
                      View all notifications
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}

              {/* User account or Sign in/up buttons */}
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="gap-2" style={{ color: theme.navbarTextColor }}>
                      <div className="h-6 w-6 rounded-full bg-slate-200 flex items-center justify-center">
                        <User className="h-4 w-4" />
                      </div>
                      <span className="hidden sm:inline-block">{username}</span>
                      <ChevronDown className="h-4 w-4 opacity-50" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>My Account</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuGroup>
                      {defaultUserMenuItems.map((item) => (
                        <DropdownMenuItem
                          key={item.href}
                          onClick={
                            item.action ? item.action : item.href !== "#" ? () => router.push(item.href) : undefined
                          }
                          className="cursor-pointer"
                        >
                          <item.icon className="mr-2 h-4 w-4" />
                          <span>{item.title}</span>
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuGroup>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : isPublicMode ? (
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={navigateToApiConsole}
                    style={{
                      borderColor: theme.buttonSecondaryColor || "#6c757d",
                      color: theme.buttonSecondaryColor || "#6c757d",
                    }}
                  >
                    <Code className="mr-2 h-4 w-4" />
                    API Console
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => setAuthModalOpen(true)}
                    style={{
                      backgroundColor: theme.buttonPrimaryColor || theme.primaryColor || "#0070f3",
                      color: theme.buttonTextColor || "#ffffff",
                    }}
                  >
                    Sign In
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    style={{ color: theme.navbarTextColor }}
                    className="font-medium"
                    size="sm"
                    onClick={() => setAuthModalOpen(true)}
                  >
                    Sign In
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => setAuthModalOpen(true)}
                    style={{
                      backgroundColor: theme.buttonPrimaryColor || theme.primaryColor || "#0070f3",
                      color: theme.buttonTextColor || "#ffffff",
                    }}
                  >
                    Sign Up
                  </Button>
                </div>
              )}
            </div>

            {/* Mobile search button */}
            {theme.navbarShowSearch && !showMobileSearch && (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 md:hidden"
                onClick={() => setShowMobileSearch(true)}
                style={{ color: theme.navbarTextColor }}
              >
                <Search className="h-5 w-5" />
                <span className="sr-only">Search</span>
              </Button>
            )}

            {/* Mobile search input */}
            {theme.navbarShowSearch && showMobileSearch && (
              <div className="flex items-center space-x-1 md:hidden flex-1 mx-2">
                <div className="relative w-full">
                  <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Search APIs..."
                    className="pl-8 h-9 w-full"
                    style={{
                      backgroundColor: `${theme.inputBackground}`,
                      borderColor: `${theme.inputBorderColor || "#d1d5db"}`,
                      color: theme.inputTextColor,
                    }}
                    autoFocus
                  />
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 flex-shrink-0"
                  onClick={() => setShowMobileSearch(false)}
                  style={{ color: theme.navbarTextColor }}
                >
                  <X className="h-5 w-5" />
                  <span className="sr-only">Close</span>
                </Button>
              </div>
            )}

            {/* Mobile menu button */}
            <Sheet>
              <SheetTrigger asChild className={cn("md:hidden", showMobileSearch && "hidden")}>
                <Button variant="ghost" size="icon" className="h-8 w-8" style={{ color: theme.navbarTextColor }}>
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent
                side="right"
                className="w-64 sm:w-80"
                style={{
                  backgroundColor: theme.navbarBackground,
                  color: theme.navbarTextColor,
                }}
              >
                <SheetHeader className="border-b pb-4 mb-4">
                  <SheetTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="relative h-8 w-8">
                        <Image
                          src={logoPath || "/placeholder.svg"}
                          alt="Logo"
                          width={32}
                          height={32}
                          className="object-contain"
                        />
                      </div>
                      {theme.siteTitle && (
                        <span className="font-semibold" style={{ color: theme.navbarTextColor }}>
                          {theme.siteTitle}
                        </span>
                      )}
                    </div>
                    <SheetClose asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8" style={{ color: theme.navbarTextColor }}>
                        <X className="h-4 w-4" />
                        <span className="sr-only">Close</span>
                      </Button>
                    </SheetClose>
                  </SheetTitle>
                </SheetHeader>

                {/* Mobile navigation */}
                <div className="space-y-4 py-4">
                  {theme.navbarShowSearch && (
                    <div className="px-2">
                      <div className="relative">
                        <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          placeholder="Search APIs..."
                          className="pl-8 w-full"
                          style={{
                            backgroundColor: `${theme.inputBackground}`,
                            borderColor: `${theme.inputBorderColor || "#d1d5db"}`,
                            color: theme.inputTextColor,
                          }}
                        />
                      </div>
                    </div>
                  )}

                  <div className="space-y-1 px-2">
                    {filteredNavItems.map((item) => (
                      <SheetClose key={item.href} asChild>
                        <Link
                          href={item.href}
                          className={cn(
                            "flex items-center py-2 px-3 text-sm rounded-md transition-colors",
                            pathname === item.href && "bg-accent/50",
                          )}
                          style={{
                            color:
                              pathname === item.href
                                ? theme.primaryColor || theme.navbarActiveColor || theme.navbarTextColor
                                : theme.navbarTextColor,
                            backgroundColor:
                              pathname === item.href
                                ? `${theme.primaryColor}10` || `${theme.navbarActiveColor}10`
                                : "transparent",
                          }}
                        >
                          {item.icon && <span className="mr-3">{item.icon}</span>}
                          {item.title}
                        </Link>
                      </SheetClose>
                    ))}
                  </div>

                  <div className="border-t pt-4">
                    {theme.navbarShowLanguage && languages.length > 0 && (
                      <div className="px-4 py-2">
                        <p className="mb-2 text-xs font-semibold uppercase tracking-wide opacity-70">Language</p>
                        <div className="grid grid-cols-2 gap-1">
                          {languages.map((lang) => (
                            <Button
                              key={lang.code}
                              variant="outline"
                              size="sm"
                              className="justify-start"
                              style={{
                                borderColor:
                                  lang.code === languages[0].code
                                    ? theme.primaryColor || "#0070f3"
                                    : theme.navbarBorderColor || theme.borderColor || "#e5e7eb",
                                color: theme.navbarTextColor,
                              }}
                            >
                              {lang.name || lang.code}
                            </Button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="mt-4 px-4 py-2">
                      {isAuthenticated ? (
                        <div className="space-y-3">
                          <div className="flex items-center">
                            <div className="h-9 w-9 rounded-full bg-slate-200 flex items-center justify-center mr-2">
                              <User className="h-5 w-5" />
                            </div>
                            <div>
                              <p className="font-medium text-sm">{username}</p>
                              <p className="text-xs opacity-70">WSO2 API Manager</p>
                            </div>
                          </div>
                          <div className="space-y-1">
                            {defaultUserMenuItems.map((item) => (
                              <SheetClose key={item.href} asChild>
                                <Link
                                  href={item.href !== "#" ? item.href : ""}
                                  onClick={item.action}
                                  className={cn(
                                    "flex items-center py-2 px-3 text-sm rounded-md transition-colors",
                                    item.title === "Sign out" && "text-red-500",
                                  )}
                                >
                                  <item.icon className="mr-2 h-4 w-4" />
                                  {item.title}
                                </Link>
                              </SheetClose>
                            ))}
                          </div>
                        </div>
                      ) : isPublicMode ? (
                        <div className="space-y-3">
                          <Button
                            className="w-full"
                            onClick={navigateToApiConsole}
                            style={{
                              backgroundColor: theme.buttonPrimaryColor || theme.primaryColor || "#0070f3",
                              color: theme.buttonTextColor || "#ffffff",
                            }}
                          >
                            <Code className="mr-2 h-4 w-4" />
                            API Console
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full"
                            onClick={() => setAuthModalOpen(true)}
                            style={{
                              borderColor: theme.buttonSecondaryColor || "#6c757d",
                              color: theme.buttonSecondaryColor || "#6c757d",
                            }}
                          >
                            Sign In
                          </Button>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full"
                            onClick={() => setAuthModalOpen(true)}
                            style={{
                              borderColor: theme.navbarBorderColor || theme.borderColor || "#e5e7eb",
                              color: theme.navbarTextColor,
                            }}
                          >
                            Sign In
                          </Button>
                          <Button
                            size="sm"
                            className="w-full"
                            onClick={() => setAuthModalOpen(true)}
                            style={{
                              backgroundColor: theme.buttonPrimaryColor || theme.primaryColor || "#0070f3",
                              color: theme.buttonTextColor || "#ffffff",
                            }}
                          >
                            Sign Up
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* WSO2 Auth Modal */}
      <WSO2AuthModal open={authModalOpen} onOpenChange={setAuthModalOpen} onAuthSuccess={handleAuthSuccess} />
    </>
  )
}
