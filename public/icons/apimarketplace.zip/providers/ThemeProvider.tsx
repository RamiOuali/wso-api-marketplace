"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import type { Theme } from "@/types/theme"
import { getThemeData } from "@/lib/theme"

interface ThemeContextType {
  theme: Theme | null
  isLoading: boolean
  error: Error | null
}

const ThemeContext = createContext<ThemeContextType>({
  theme: null,
  isLoading: true,
  error: null,
})

export const useThemeContext = () => useContext(ThemeContext)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    async function loadTheme() {
      try {
        setIsLoading(true)
        const themeData = await getThemeData()
        setTheme(themeData)
      } catch (err) {
        console.error("Failed to load theme:", err)
        setError(err instanceof Error ? err : new Error("Failed to load theme"))
      } finally {
        setIsLoading(false)
      }
    }

    loadTheme()
  }, [])

  return <ThemeContext.Provider value={{ theme, isLoading, error }}>{children}</ThemeContext.Provider>
}
