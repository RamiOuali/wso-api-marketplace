"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ApiDetail } from "@/components/wso2/api-detail"
import { WSO2AuthService } from "@/lib/wso2/auth-service"
import { use } from "react"

export default function ApiDetailPage({ params }: { params: { id: string } }) {
  // Use React.use() to unwrap the params
  const apiId = use(Promise.resolve(params.id))
  const router = useRouter()
  const [baseUrl, setBaseUrl] = useState<string>("")
  const [authService, setAuthService] = useState<WSO2AuthService | null>(null)
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    // Get connection details from localStorage
    try {
      const storedBaseUrl = localStorage.getItem("wso2_baseUrl")

      if (!storedBaseUrl) {
        // Redirect to connection page if no base URL is found
        router.push("/wso2")
        return
      }

      setBaseUrl(storedBaseUrl)

      // Check if we have client credentials
      const clientId = localStorage.getItem("wso2_clientId")
      const clientSecret = localStorage.getItem("wso2_clientSecret")
      const accessToken = localStorage.getItem("wso2_accessToken")
      const refreshToken = localStorage.getItem("wso2_refreshToken")
      const tokenExpiry = localStorage.getItem("wso2_tokenExpiry")

      if (clientId && clientSecret && accessToken && refreshToken && tokenExpiry) {
        // Create auth service with stored credentials
        const auth = new WSO2AuthService(storedBaseUrl)

        // Set auth service properties
        Object.assign(auth, {
          clientId,
          clientSecret,
          accessToken,
          refreshToken,
          tokenExpiry: Number.parseInt(tokenExpiry, 10),
        })

        setAuthService(auth)
      }
    } catch (error) {
      console.error("Error accessing localStorage:", error)
    } finally {
      setLoading(false)
    }
  }, [router])

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <div className="text-center">
          <p>Loading...</p>
        </div>
      </div>
    )
  }

  return <ApiDetail baseUrl={baseUrl} apiId={apiId} authService={authService || undefined} />
}
