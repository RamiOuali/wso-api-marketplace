import { ImageCardsEditor } from "@/components/admin/sections/image-cards-editor"

export default function ImageCardsPage() {
  return <ImageCardsEditor />
}
