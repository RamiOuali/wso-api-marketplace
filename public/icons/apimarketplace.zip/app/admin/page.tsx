import { AdminDashboardOverview } from "@/components/admin/admin-dashboard-overview"

export default function AdminDashboard() {
  return <AdminDashboardOverview />
}
