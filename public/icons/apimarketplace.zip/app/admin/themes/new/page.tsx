import { ThemeEditor } from "@/components/admin/themes/theme-editor"

export default function NewThemePage() {
  return <ThemeEditor isNew />
}
