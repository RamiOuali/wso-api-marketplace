import { ThemesList } from "@/components/admin/themes/themes-list"

export default function ThemesPage() {
  return <ThemesList />
}
