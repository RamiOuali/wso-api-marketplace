import { Hero } from "@/components/hero"
import { FeatureCards } from "@/components/feature-cards"
import { ApiList } from "@/components/api-list"
import { ImageCardsSection } from "@/components/sections/image-cards-section"

// Sample image cards data
const imageCards = [
  {
    id: "1",
    imageUrl: "/placeholder.svg?height=400&width=600",
    alt: "API Dashboard",
  },
  {
    id: "2",
    imageUrl: "/placeholder.svg?height=400&width=600",
    alt: "API Documentation",
  },
  {
    id: "3",
    imageUrl: "/placeholder.svg?height=400&width=600",
    alt: "API Analytics",
  },
]

export default function Home() {
  return (
    <div>
      <Hero />
      <FeatureCards />
      <ImageCardsSection
        title="API Showcase"
        subtitle="Visual examples of our API integrations and use cases"
        cards={imageCards}
        columns={3}
        gap="medium"
        rounded="medium"
        shadow="medium"
        aspectRatio="landscape"
        hoverEffect="zoom"
      />
      <ApiList />
    </div>
  )
}
